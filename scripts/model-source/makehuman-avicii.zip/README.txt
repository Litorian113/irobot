MakeHuman shape targets (CC0), makehumancommunity/makehuman revision a8bc2d54ff0ac92e78ff71431b1023eda42bf482,
makehuman/data/targets. See scripts/model-source/LICENSE-CC0.md.
